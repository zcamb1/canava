### USER
[DEVICES]: Here are the list of devices that you can control and monitor.
* location_1: "สำนักงาน"
    * No rooms

* location_3: "บ้าน BLR"
    * room_2: "ห้องนั่งเล่น"
        * device_room_2: AllDevices, all devices in "ห้องนั่งเล่น"
        * device_2: SmartMonitor, "32 Smart Monitor M7", "off"

* location_2: "BM วิน"
    * room_1: "ห้องนั่งเล่น"
        * device_room_1: AllDevices, all devices in "ห้องนั่งเล่น"
        * device_1: SmartMonitor, "32 Odyssey G6", "disconnected"


[SCENES]: Here is a list of Scenes that can be executed.
* No scenes


[ENVIRONMENTS]: It refers to the current user's environment.
- daytime: morning
- locale: th-TH
- description: The user is speaking to mobile, and the user location is unknown.
- listener device: mobile


[CONVERSATIONS]: Please refer to the conversation content and decide what action to take for the user's last utterance.
- User: มีอุปกรณ์ใดที่ทำงานอยู่ตลอดเวลาที่บ้าน BLR ตอนนี้ไหม?


### RESPONSE
[{"actionType": "EXECUTION", "ids": ["location_3"]}]