### USER
[DEVICES]: Here are the list of devices that you can control and monitor.
* location_1: "สถานะของฉัน"
    * No rooms

* location_3: "บ้าน"
    * room_2: "ห้องนั่งเล่น"
        * device_room_2: AllDevices, all devices in "ห้องนั่งเล่น"
        * device_7: SmartLock, "ประตูหน้า"
    * room_14: "ห้องดนตรี"
        * device_room_14: AllDevices, all devices in "ห้องดนตรี"
        * device_5: Television, "Samsung The Frame 43", "disconnected"
        * device_28: Projector, "โปรเจคเตอร์ Freestyle", "disconnected"
    * room_12: "ห้องครัว"
        * device_room_12: AllDevices, all devices in "ห้องครัว"
        * device_3: Hub, "ฮับ SmartThings FamilyHub"
        * device_21: Refrigerator, "ตู้เย็น", "on, TemperatureSetting 34℃"
        * device_18: Dishwasher, "เครื่องล้างจาน", "off"
    * room_13: "ห้องสื่อ"
        * device_room_13: AllDevices, all devices in "ห้องสื่อ"
        * device_4: Charger, "SmartThings Station", "disconnected"
        * device_10: WiFiRouter, "Wifi บ้าน X"
        * device_15: Hub, "SmartThings Station", "disconnected"
        * device_16: Hub, "ฮับ SmartThings"
    * room_6: "ห้องนอนของ โอม"
        * device_room_6: AllDevices, all devices in "ห้องนอนของ โอม"
        * device_13: Light, "ไฟสำหรับ Shellton", "off"
    * room_4: "ห้องเล่นเกม"
        * No devices
    * room_10: "กลางแจ้ง"
        * device_room_10: AllDevices, all devices in "กลางแจ้ง"
        * device_group_3: Light, all Lights in "กลางแจ้ง"
        * device_12: Light, "ไฟประตูโรงรถฝั่งซ้าย", "off"
        * device_20: Light, "ไฟประตูโรงรถฝั่งขวา", "off"
    * room_11: "กำลังออกไป"
        * No devices
    * room_5: "ห้องหลัก"
        * No devices
    * room_1: "ห้องนอน Kate"
        * No devices
    * room_7: "ห้องซักรีด"
        * device_room_7: AllDevices, all devices in "ห้องซักรีด"
        * device_14: Washer, "เครื่องซักผ้า", "disconnected"
        * device_17: Dryer, "เครื่องอบผ้า", "off"
    * room_8: "ห้องสำนักงาน"
        * device_room_8: AllDevices, all devices in "ห้องสำนักงาน"
        * device_6: SmartMonitor, "32 Smart Monitor M8", "disconnected"
        * device_31: SmartPlug, "สมาร์ทปลั๊ก Wifi", "off"
    * room_9: "รอดำเนินการ"
        * device_room_9: AllDevices, all devices in "รอดำเนินการ"
        * device_9: SmartLock, "Xiao", "disconnected"

* location_2: "บ้าน 1044"
    * room_3: "กลางแจ้ง"
        * No devices


[SCENES]: Here is a list of Scenes that can be executed.
* No scenes


[ENVIRONMENTS]: It refers to the current user's environment.
- daytime: night
- locale: th-TH
- description: The user is speaking to mobile, and the user location is unknown.
- listener device: mobile


[CONVERSATIONS]: Please refer to the conversation content and decide what action to take for the user's last utterance.
- User: ตู้เย็นในครัวตั้งอุณหภูมิไว้ที่เท่าไหร่?


### RESPONSE
[{"actionType": "EXECUTION", "ids": ["device_21"]}]