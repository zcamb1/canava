### USER
[DEVICES]: Here are the list of devices that you can control and monitor.
* location_1: "บ้าน"
    * room_2: "กำลังออกไป"
        * No devices
    * room_1: "ห้องนั่งเล่น"
        * device_room_1: AllDevices, all devices in "ห้องนั่งเล่น"
        * device_5: NetworkAudio, "ซาวด์บาร์ Samsung S800B", "disconnected"
    * room_3: "ห้องนอน 1"
        * device_room_3: AllDevices, all devices in "ห้องนอน 1"
        * device_1: SmartMonitor, "จอภาพ", "disconnected"
        * device_3: LightSensor, "เซ็นเซอร์แสง 75 Crystal UHD", "disconnected"


[SCENES]: Here is a list of Scenes that can be executed.
* No scenes


[ENVIRONMENTS]: It refers to the current user's environment.
- daytime: night
- locale: th-TH
- description: The user is speaking to mobile, and the user location is unknown.
- listener device: mobile


[CONVERSATIONS]: Please refer to the conversation content and decide what action to take for the user's last utterance.
- User: เซ็นเซอร์แสงเชื่อมต่ออยู่หรือไม่?


### RESPONSE
[{"actionType": "EXECUTION", "ids": ["device_3"]}]