### USER
[DEVICES]: Here are the list of devices that you can control and monitor.
* location_1: "Nhà"
    * room_2: "Đang ra ngoài"
        * No devices
    * room_1: "Phòng khách"
        * device_room_1: AllDevices, all devices in "Phòng khách"
        * device_5: NetworkAudio, "Loa thanh Samsung S800B", "disconnected"
    * room_3: "Phòng ngủ 1"
        * device_room_3: AllDevices, all devices in "Phòng ngủ 1"
        * device_1: SmartMonitor, "màn hình", "disconnected"
        * device_3: LightSensor, "Cảm biến ánh sáng 75 Crystal UHD", "disconnected"


[SCENES]: Here is a list of Scenes that can be executed.
* No scenes


[ENVIRONMENTS]: It refers to the current user's environment.
- daytime: night
- locale: vi-VN
- description: The user is speaking to mobile, and the user location is unknown.
- listener device: mobile


[CONVERSATIONS]: Please refer to the conversation content and decide what action to take for the user's last utterance.
- User: Màn hình có đang bật không?


### RESPONSE
[{"actionType": "EXECUTION", "ids": ["device_1"]}]