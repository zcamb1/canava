### USER
[DEVICES]: Here are the list of devices that you can control and monitor.
* location_1: "Nhà tôi"
    * room_2: "Đang ra ngoài"
        * device_room_2: AllDevices, all devices in "Đang ra ngoài"
        * device_27: Projector, "Máy chiếu Samsung Freestyle", "disconnected"
    * room_6: "Phòng khách"
        * No devices
    * room_8: "Phòng ăn"
        * No devices
    * room_7: "Nhà"
        * device_room_7: AllDevices, all devices in "Nhà"
        * device_18: LightSensor, "Cảm biến ánh sáng The Frame", "disconnected"
        * device_14: Thermostat, "Nhà", "TemperatureSetting 75℃"
        * device_30: MotionSensor, "Tầng trên"
        * device_31: Television, "The Frame", "disconnected"
        * device_20: Siren, "Nhà AK phía trước"
        * device_26: Siren, "Nhà AK phía sau"
        * device_25: RobotCleaner, "Robot hút bụi Duster", "on, Cleaning stop"
        * device_5: RobotCleaner, "Robot hút bụi Babe", "on, Cleaning stop"
    * room_9: "Ngoài trời"
        * device_room_9: AllDevices, all devices in "Ngoài trời"
        * device_22: Camera, "Lối đi phía trước", "on"
        * device_33: Camera, "Phía trước hướng Nam", "on"
        * device_8: Camera, "Ga-ra", "on"
        * device_32: Camera, "Sân sau hướng Đông Nam", "on"
        * device_1: Camera, "Phía trước hướng Bắc", "on"
        * device_24: Camera, "Phía trước", "on"
        * device_7: Camera, "Cửa trước", "on"
        * device_3: Camera, "Sân sau hướng Đông Bắc", "on"
        * device_21: Camera, "Cửa sau", "on"
        * device_group_2: Light, all Lights in "Ngoài trời"
        * device_4: Light, "Đèn lối đi hướng Bắc", "off"
        * device_2: Light, "Đèn lối đi phía trước", "off"
        * device_29: Light, "Đèn ga-ra", "off"
    * room_3: "Phòng của Lan"
        * device_room_3: AllDevices, all devices in "Phòng của Lan"
        * device_28: ClothingCareMachine, "Tủ chăm sóc quần áo nhỏ", "off"
        * device_17: NetworkAudio, "Khung nhạc", "off"
    * room_1: "Phòng sinh hoạt chung"
        * device_room_1: AllDevices, all devices in "Phòng sinh hoạt chung"
        * device_23: Television, "TV phòng sinh hoạt chung", "off"
    * room_4: "Nhà bếp"
        * device_room_4: AllDevices, all devices in "Nhà bếp"
        * device_6: Dishwasher, "Máy rửa bát", "off"
    * room_5: "Phòng ngủ chính"
        * device_room_5: AllDevices, all devices in "Phòng ngủ chính"
        * device_19: ClothingCareMachine, "Tủ chăm sóc quần áo lớn", "off"


[SCENES]: Here is a list of Scenes that can be executed.
* location_1: "Nhà tôi"
    * scene_2: "Chào buổi sáng"
    * scene_1: "Chúc ngủ ngon"


[ENVIRONMENTS]: It refers to the current user's environment.
- daytime: noon
- locale: vi-VN
- description: The user is speaking to mobile, and the user location is unknown.
- listener device: mobile


[CONVERSATIONS]: Please refer to the conversation content and decide what action to take for the user's last utterance.
- User: Có thiết bị nào hiện đang hoạt động trong phòng 'Đang ra ngoài' không?


### RESPONSE
[{"actionType": "EXECUTION", "ids": ["room_2"]}]