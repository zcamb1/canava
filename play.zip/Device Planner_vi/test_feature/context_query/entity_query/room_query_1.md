### USER
[DEVICES]: Here are the list of devices that you can control and monitor.
* location_1: "văn phòng"
    * No rooms

* location_3: "Nhà BLR"
    * room_2: "Phòng khách"
        * device_room_2: AllDevices, all devices in "Phòng khách"
        * device_2: SmartMonitor, "32 Smart Monitor M7", "off"

* location_2: "BM Vinh"
    * room_1: "Phòng khách"
        * device_room_1: AllDevices, all devices in "Phòng khách"
        * device_1: SmartMonitor, "32 Odyssey G6", "disconnected"


[SCENES]: Here is a list of Scenes that can be executed.
* No scenes


[ENVIRONMENTS]: It refers to the current user's environment.
- daytime: morning
- locale: vi-VN
- description: The user is speaking to mobile, and the user location is unknown.
- listener device: mobile


[CONVERSATIONS]: Please refer to the conversation content and decide what action to take for the user's last utterance.
- User: Có những thiết bị nào trong phòng khách của BM Vinh?


### RESPONSE
[{"actionType": "EXECUTION", "ids": ["room_1"]}]